#!/bin/bash

source /afs/umbc.edu/software/cadence/etc/setup_2017/cadence6.bashrc

ncelab $*
