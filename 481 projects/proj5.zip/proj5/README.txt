CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Execution
 * Restrictions
 
 
INTRODUCTION

---------------------

This program takes implements a message passing within 5 processes in the ring topology network using TCP socket programming.

EXECUTION

---------------------

Compiling:
    The program can be compiled using the command 'gcc -pthread -o main main.c'

Running:
    To run the program use the command './main'

RESTRICTIONS

---------------------
The output is not always consistant due to port issues.